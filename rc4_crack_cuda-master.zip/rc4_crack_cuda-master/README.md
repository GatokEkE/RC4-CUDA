rc4_crack_cuda
==============

crack rc4 key with cuda
