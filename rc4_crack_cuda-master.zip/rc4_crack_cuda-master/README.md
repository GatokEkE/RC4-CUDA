rc4_crack_cuda
==============

crack rc4 key with cuda

This is a rewrite of morningForever's project. Currently the plaintext, key and various parameters are set as constants during compile time. The RC4 kernel is very fast. Contributions welcome.
